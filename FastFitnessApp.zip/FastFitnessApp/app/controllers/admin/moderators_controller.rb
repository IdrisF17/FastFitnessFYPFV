class Admin::ModeratorsContorller < ApplicationController
	def index 
	end 
end 