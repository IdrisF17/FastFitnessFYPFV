class Setting < ActiveRecord::Base
end
