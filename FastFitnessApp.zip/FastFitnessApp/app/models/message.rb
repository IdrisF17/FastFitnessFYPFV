class Message < ActiveRecord::Base
  belongs_to :visitor
end
