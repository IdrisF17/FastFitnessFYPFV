# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

# creation of seed data for Moderator
moderator = Moderator.create!(
		fullname: 'Reggie Rake', 
		username: 'Reggie', 
		password: '123456789'
	)
