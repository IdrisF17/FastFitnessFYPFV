
// This example requires the Places library. Include the libraries=places
// parameter when you first load the API. For example:
// <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_API_KEY&libraries=places">

var map;
var res;
var infowindow;
var res = [];
var service;


$(document).on('ready',function(){
   getLocation()
});

function initMap() {
var search = arguments[0] != undefined ? arguments[0] : {lat: -33.867, lng: 151.195};

map = new google.maps.Map(document.getElementById('map'), {
  center: search,
  zoom: 15
  
});

infowindow = new google.maps.InfoWindow();

service = new google.maps.places.PlacesService(map);
service.nearbySearch({
  location: map.getCenter(),
  radius: 500,
  types: ['gym'] 
  }, callback);
}


// will print the gym details to the results area
function getPlace(id, i) {
  service.getDetails({
    placeId: id
  }, function(place, status) {

    console.log(place);
    // check to see if there are any photos Available
    if (place.photos != undefined) {

      // request the first Available photo with a specific max an dmin width and height
      var photo = place.photos[0].getUrl({'maxWidth': 500, 'maxHeight': 500});

      // hack to switch back to default images
      //var photo = false;
    }

    $('#results').append(function ()
      {
        var text = '<br/><br/>'+`
          <div class="row">
              <div class="col-md-7">
                  <a href="#">`;

                  // check if photo has a value that is somthing other than false
                  if (photo)
                  {
                    // set the image to the requested photo
                    text += `<img class="img-responsive" src="`+photo+`" alt="">`
                  }
                  else
                  {
                    // set the image to the defualt stock image
                    text = `<img class="img-responsive" src="img/gym-700x300.jpg" alt="">`
                  }


                  text+=`</a>

              </div>
              <div class="col-md-5">
                  <h3 id="">`+place.name+`</h3>
                  <h4>`+place.formatted_address+`</h4>`;

              // push the returned object into an array
              res.push(place)

              // stringify and store a local variable holding the object array
              localStorage.setItem('results', JSON.stringify(res))

              text += `<a class="btn btn-primary" onclick='move(`+i+`)'>View Gym <span class="glyphicon glyphicon-chevron-right"></span></a></br></br>

                </div>
            </div>

            </div><div class='break_line'></div>`

        return text;

      })

  })
 }

function callback(results, status) {

  // checks if the response from our request was ok
  if (status === google.maps.places.PlacesServiceStatus.OK) {

    for (var i = 0; i < results.length; i++) {

      // creates a marker for the map
      createMarker(results[i]);

      // will send details of gyms to be printed
      getPlace(results[i].place_id, i)

    }
  }
}

function move(val) {

  // will set a new windows location and send over the
  // value of the selected gym
  window.location.assign('SearchGyms.html?Search='+val)

}

//creates the marker for the map
function createMarker(place) {

  // stores the location of the current place
  var placeLoc = place.geometry.location;

  // creates a new maker using the location of place
  // and the global map
  var marker = new google.maps.Marker({
    map: map,
    position: place.geometry.location
  });

  // addin a click listner to the marker to display a info window
  google.maps.event.addListener(marker, 'click', function() {

    // setting the info to be displayed on the popup
    infowindow.setContent(place.name);

    // will open the map with the intstance of this marker
    infowindow.open(map, this);

  });
}


// will get the current location of the user
function getLocation() {

  // check to see if this function is supported by the browser
  if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(showPosition);
  } else {
      alert("Geolocation is not supported by this browser.")
  }
}

function showPosition(position) {

  // log debug
  console.log("Latitude: " + position.coords.latitude +
  "<br>Longitude: " + position.coords.longitude);

  // clear the results area ready for new results
  $('#results').html('');

  // re-initialise the map with the new co-ordinates
  initMap({lat: position.coords.latitude, lng: position.coords.longitude})
}
