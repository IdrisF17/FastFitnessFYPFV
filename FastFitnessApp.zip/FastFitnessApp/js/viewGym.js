

var avg = 0;


$(document).on('ready',function(){

  // parse and collect the lcal stored results
  var res = JSON.parse(localStorage.getItem('results'))

  // select the correct associated gym
  var gym = window.location.search.split('=')[1]

  // set the associated image
  $('.img-responsive').attr('src', 'img/gym-700x300.jpg')

  // set the name of the gym
  $('.gym_title').html(res[gym].name)

  // set the descritption
  $('.gym_description').html(res[gym])

  console.log(res[gym]);


  // setting up the reviews
  //check if there are any reviews
  var reviewExist = res[gym].reviews != undefined ? true : false
  var "types" : [ "postal_code" ]

  function getAverage() {

    for (var i = 0; i < res[gym].reviews.length; i++) {

      //print review
      printReview(
        res[gym].reviews[i].author_name,
        res[gym].reviews[i].text,
        res[gym].reviews[i].time,
        res[gym].reviews[i].rating)


      // add all the ratings together
      avg += res[gym].reviews[i].rating

    }
    // calculate the average from the total
    avg = avg/res[gym].reviews.length


    for (var i = 0; i < 5; i++) {
      if (avg > i) {
        $('.average_stars').append(`
          <span class="glyphicon glyphicon-star"></span>`)
      }else {
        $('.average_stars').append(`
          <span class="glyphicon glyphicon-star-empty"></span>`)
      }
    }
    $('.average_stars').append(`<br>`+avg +`.0 Stars`)
  }


  // funtion will print and append new reviews the the list
  function printReview(name, msg, time, rating) {
    $('.reviews').append(function () {
      var rvw = `
        <div class="row">
            <div class="col-md-12">
            `+name+`<br>`;

            for (var i = 0; i < 5; i++) {
              if (rating > i) {
                rvw += `<span class="glyphicon glyphicon-star"></span>`;
              }else {
                rvw += `<span class="glyphicon glyphicon-star-empty"></span>`;
              }
            }
              rvw +=` <span class="pull-right">`+new Date(time*1000)+`</span><br><br>
                <p>`+msg+` </p>
            </div>
        </div>

        <hr>`;

        return rvw
    })
  }


  // check if there are any reviews
  if (reviewExist){

    // state the amount of reviews
    $('.review_count').html(res[gym].reviews.length +' Reviews' )

    // will calculate the average rating
    getAverage();

  }else{
    // will set the review count to 0
    $('.review_count').html('0'+' Reviews' )

    // will append 5 blank starts
    for (var i = 0; i < 5; i++) {

        // blank star
        $('.average_stars').append(`
          <span class="glyphicon glyphicon-star-empty"></span>`)

    }
    // 0 star rating
    $('.average_stars').append(`<br>`+avg +`.0 Stars`)
  }

})
